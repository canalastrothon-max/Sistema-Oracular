# Site — Sistema Oracular

Arquivos prontos para publicação no GitHub Pages.

## Publicação

1. Copie `index.html`, `styles.css`, `.nojekyll` e a pasta `.github` para a raiz do repositório.
2. No GitHub, abra **Settings → Pages**.
3. Em **Build and deployment → Source**, selecione **GitHub Actions**.
4. Faça um commit na branch `main`.
5. O site será publicado em:

`https://canalastrothon-max.github.io/Sistema-Oracular/`
